package com.cg.client;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Employee;

public class DynamicQueryDemo {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		String qry="select emp from Employee emp where emp.empid=:id";
		TypedQuery<Employee> query = manager.createQuery(qry,Employee.class);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id to Search");
		int empid=sc.nextInt();
		query.setParameter("id", empid);
		Employee employee = query.getSingleResult();
		System.out.println(employee.getEmpname() +" "+employee.getEmpsal());
		manager.getTransaction().commit();
		manager.close();
		factory.close();
	}

}
