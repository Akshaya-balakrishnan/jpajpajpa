package com.cg.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class QueryDemo {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		String qry="select emp from Employee emp where emp.empsal>30000";
		Query query=em.createQuery(qry);
		List list=query.getResultList();
		for(Object obj:list)
		{
			System.out.println(obj);
		}
		em.getTransaction().commit();
		em.close();
		factory.close();
		
	}

}
